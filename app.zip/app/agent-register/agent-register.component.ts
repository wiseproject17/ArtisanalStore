import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EncrDecrServiceService } from '../encr-decr-service.service';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from '../customer.service';
@Component({
  selector: 'app-agent-register',
  templateUrl: './agent-register.component.html',
  styleUrls: ['./agent-register.component.css']
})
export class AgentRegisterComponent implements OnInit {

  agent:any;
  constructor(private router: Router,private service: CustomerService,private toastr: ToastrService,private EncrDecr: EncrDecrServiceService) {
    this.agent = {agentId:'',city:'',dealingVillage:'',emailId:'',firstName:'',lastName:'',phone:'',street:'',password:''

    };
  }

  ngOnInit() {
    document.body.classList.add('registerbg-img');
  }
  ngOnDestroy(){
    document.body.classList.remove('registerbg-img');
  }

  registerAgent() {
    this.service.registerAgent(this.agent).subscribe((result: any) => { console.log(result); } );
    console.log(this.agent);
    //alert('Registration Successful');
    this.toastr.success('For Registering','Thank You',{timeOut:2000});
    this.router.navigate(['login']);
  }
}
