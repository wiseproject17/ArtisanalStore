import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.css']
})
export class AddProductComponent implements OnInit, OnDestroy {
  imageUrl: string;
  fileToUpload: File = null;
  reader: FileReader;
  product: any;
  user : any;
  constructor(private router: Router,private service: CustomerService,private toastr: ToastrService,) {
    this.imageUrl = '/assets/Images/default-image.jpg';
  }
  ngOnInit() {
    document.body.classList.add('addproductbg-img');
  }
  ngOnDestroy(){
    document.body.classList.remove('addproductbg-img');
  }
  remove(){
    localStorage.removeItem('user');

  }
  /*registerProduct(): void {
    this.service.registerProduct(this.product).subscribe((result: any) => { console.log(result); } );
    console.log(this.product);
    alert('Product details updated Successfully');
    this.router.navigate(['agentProduct']);
  }
*/
  handleFileInput(file: FileList){
    this.fileToUpload = file.item(0);
    this.reader = new FileReader();
    this.reader.readAsDataURL(this.fileToUpload);
    this.reader.onload = (event: any) => {
      this.imageUrl = event.target.result;
    };
  }
  OnSubmit(imageForm: any) {
    this.user = JSON.parse(localStorage.getItem('user'));
    imageForm.agentId = this.user.agentId;
    console.log(imageForm);
    this.service.postFile(imageForm, this.fileToUpload).subscribe (
      data => {
        console.log('done');
        this.toastr.success('Successfully','Product Registered', {timeOut:2000});
        //this.imageUrl = '/assets/Images/img1.jpg';
      }
    );
  }
}


  // handleFileInput(file: FileList) {
  //   this.fileToUpload = file.item(0);

  //   // Show image preview
  //   this.reader = new FileReader();
  //   this.reader.readAsDataURL(this.fileToUpload);
  //   this.reader.onload = (event: any) => {
  //     this.imageUrl = event.target.result;
  //   };
  // }

  // OnSubmit(imageForm: any) {
  //  this.service.postFile(imageForm, this.fileToUpload).subscribe(
  //    data => {
  //      console.log('done');
  //      this.imageUrl = '/assets/image/default.png';
  //    }
  //  );
  //

