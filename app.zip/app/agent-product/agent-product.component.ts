import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { ToastrService } from 'ngx-toastr';
declare var jQuery: any;
@Component({
  selector: 'app-agent-product',
  templateUrl: './agent-product.component.html',
  styleUrls: ['./agent-product.component.css']
})
export class AgentProductComponent implements OnInit {
  products: any;
  oldquantity : number;
  item :any; 
  constructor(private router: Router,private service: CustomerService, private toastr: ToastrService) {
    this.item = {proId: '', proName : '', description : '', price : '', proImage : '', quantity : '', catName : ''};
  }
  ngOnInit() {
    this.service.getProducts().subscribe( (result: any) => {console.log(result); this.products = result; });
  } 

  showEditPopup(product: any) { 
    this.item = product;
    this.oldquantity = this.item.quantity;
    jQuery('#productModel').modal('show');
  }
  update() {
    this.item.quantity = this.item.quantity + this.oldquantity;
    this.service.updateProduct(this.item).subscribe();
    this.toastr.success('Successfully','Order Placed', {timeOut:2000});
    console.log(this.item);
  }

}
