import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';
import * as $ from "jquery";

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
}) 
export class HeaderComponent implements OnInit {
  products: any;
  user: any;
  pots:string;
  // items = [];
  constructor(private router: Router,private service: CustomerService) {
    
  }

  ngOnInit() {

      $(document).ready(function () {
          $('#sidebarCollapse').on('click', function () {
              $('#sidebar').toggleClass('active');
          });
      });

   // this.service.getForCart().subscribe(result => this.items.push(result));
  } 
  
  addToCart(product : any){
    this.service.addToCart(product);
  }
  logoutUser() {
    // this.items = [];
    this.service.isUserLogged = false;
    this.service.removeItemsFromCart();
    localStorage.removeItem('user')
    localStorage.removeItem("product");
    this.router.navigate(['/login'])
  }
}
