import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl,ReactiveFormsModule} from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from '../customer.service';


@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
  currentUser : any;
  updateForm : FormGroup;
  editcustomer : any;
  constructor(private fb: FormBuilder,private router: Router,private toastr: ToastrService,private service: CustomerService) {
    this.editcustomer = {customerId: '',address: '', district: '',emailId: '', password: '', phone: '',state:'', userName: '',conPassword: ''};
  }

  ngOnInit() {
    // document.body.classList.add('updateimagebg-img');
    this.currentUser = JSON.parse(localStorage.getItem("user"));
    console.log(this.currentUser.userName);
    this.updateForm = this.fb.group({
      UserName:  ['', [Validators.required]],
      Address:['',[Validators.required]],
      Phone:['',[Validators.required]],
      Email:['',[Validators.required]],
      District:['',[Validators.required]],
      State:['',[Validators.required]],

    });
    this.updateForm.controls['UserName'].setValue(this.currentUser.userName);
    this.updateForm.controls['Phone'].setValue(this.currentUser.phone);
    this.updateForm.controls['Email'].setValue(this.currentUser.emailId);
    this.updateForm.controls['Address'].setValue(this.currentUser.address);
    this.updateForm.controls['District'].setValue(this.currentUser.district);
    this.updateForm.controls['State'].setValue(this.currentUser.state);
  }
  // ngOnDestroy(){
  //   document.body.classList.remove('updateimagebg-img');
  // }
  Update(){
    
    this.editcustomer.customerId = this.currentUser.customerId;
    this.editcustomer.password = this.currentUser.password;
    this.editcustomer.conPassword = this.currentUser.conPassword;
    this.editcustomer.userName=this.updateForm.controls['UserName'].value;
    this.editcustomer.phone=this.updateForm.controls['Phone'].value;
    this.editcustomer.emailId=this.updateForm.controls['Email'].value;
    this.editcustomer.address=this.updateForm.controls['Address'].value;
    this.editcustomer.district=this.updateForm.controls['District'].value;
    this.editcustomer.state=this.updateForm.controls['State'].value;
    console.log("service method called in ts...");
    this.service.update(this.editcustomer).subscribe();
    this.toastr.success('Successfully','Profile Updated', {timeOut:2000});
    //this.service.usermail(this.currentUser).subscribe( (result: any) => {console.log(result); });
  }

}
