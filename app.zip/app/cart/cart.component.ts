import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl,ReactiveFormsModule} from '@angular/forms';
import { CustomerService } from '../customer.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  currentUser : any;
  cartItems = [];
  quant = [];
  flag : number;
  orderDetailsList = [];
  allTotal : number;
  deliveryForm:FormGroup;
  constructor(private service:CustomerService,private fb: FormBuilder,private toastr: ToastrService, private router: Router) { 
    this.flag = 1;
    this.quant = [];
    this.cartItems = this.service.cartItems;
    console.log(this.service.cartItems);
  }

  ngOnInit() {
    
    this.currentUser = JSON.parse(localStorage.getItem("user"));
    for (let i in this.cartItems) {
      this.quant[i] = this.cartItems[i].quantity;
      this.cartItems[i].quantity=1;
   }
    this.calculteAllTotal(this.cartItems);
    this.service.addProductToCart(this.cartItems);
    // this.deliveryForm.userName = this.currentUser.userName;
    this.deliveryForm = this.fb.group({
      UserName:  ['', [Validators.required]],
      DeliveryAddress:['',[Validators.required]],
      Phone:['',[Validators.required]],
      Email:['',[Validators.required]],
      Message:['',[]],
      Amount:['',[Validators.required]],
  
    });
    this.deliveryForm.controls['UserName'].setValue(this.currentUser.userName);
    this.deliveryForm.controls['Phone'].setValue(this.currentUser.phone);
    this.deliveryForm.controls['Email'].setValue(this.currentUser.emailId);
    this.deliveryForm.controls['DeliveryAddress'].setValue(this.currentUser.address);
    this.deliveryForm.controls['Amount'].setValue(this.allTotal);
  }
  deleteItem(product) {
    console.log(product);
    for (let i = 0; i < this.cartItems.length; i += 1) {
      if(this.cartItems[i].proId == product.proId){
        this.cartItems[i].quantity = 0;
        this.cartItems.splice(i, 1);
      }
    }
    this.calculteAllTotal(this.cartItems);
    this.deliveryForm.controls['Amount'].setValue(this.allTotal);
  }
  calculteAllTotal(cartItems)
  {
    let total=0;
    for (let i in cartItems) {
      total= total+(cartItems[i].quantity *cartItems[i].price);
   }
  this.allTotal =total;
  }
  onAddQuantity(product)
  {

    for (let i in this.cartItems) {
        if(this.cartItems[i].proId == product.proId ){
          if(product.quantity + 1 <= this.quant[i]){
            this.cartItems[i].quantity = product.quantity + 1;
          }
          else{
            this.flag = 0;
            alert('stock not available');
          }
        }
   }
  this.service.removeAllProductFromCart();
  this.service.addProductToCart(this.cartItems);
  this.calculteAllTotal(this.cartItems);
  this.deliveryForm.controls['Amount'].setValue(this.allTotal);
   
  }
  onRemoveQuantity(product)
  {
    for (let i in this.cartItems) {
      if(this.cartItems[i].proId == product.proId){
        if(product.quantity - 1 <= this.quant[i]){
          this.flag = 1;
          this.cartItems[i].quantity = product.quantity - 1;
        }
      }
    }
    this.service.removeAllProductFromCart();
    this.service.addProductToCart(this.cartItems);
    this.calculteAllTotal(this.cartItems);
    this.deliveryForm.controls['Amount'].setValue(this.allTotal);

  }
  ConfirmOrder(){
    let orderedDate = new Date().toLocaleDateString();
    let deliveryAddress=this.deliveryForm.controls['DeliveryAddress'].value; 
    let phoneNo=this.deliveryForm.controls['Phone'].value;
    let totalPrice = this.allTotal;
    this.service.confirmOrder(orderedDate, deliveryAddress, phoneNo, totalPrice).subscribe((result: any) => { console.log(result); });
    this.toastr.success('Successfully','Order Placed', {timeOut:2000});
    //this.service.usermail(this.currentUser).subscribe( (result: any) => {console.log(result); });
    this.service.removeItemsFromCart();
    // this.router.navigate(['order-details']);
  }
}
  // ConfirmOrder(){

  //   let order:any={};
    
  //   let today = new Date().toLocaleDateString()
  //   console.log(today)
  //   console.log(typeof(today));

  //   order.customer=this.currentUser;
  //   order.deliveryAddress=this.deliveryForm.controls['DeliveryAddress'].value;
  //   order.phoneNo=this.deliveryForm.controls['Phone'].value;
  //   order.totalPrice = this.allTotal;
  //   order.orderedDate = today;
  

  //   for (let i = 0 ; i < this.cartItems.length; i++) {
  //         this.orderDetailsList.push({
  //           orders : order,
  //           product: this.cartItems[i],
  //           quantity : this.cartItems[i].quantity,
  //           unitPrice : this.cartItems[i].price
  //         });
  //      }
    
  //   console.log(order);
  //   console.log(this.orderDetailsList);
  //   this.service.sendOrder(order).subscribe((result: any) => { console.log(result); });
  //   this.service.sendOrderItems(this.orderDetailsList).subscribe((result: any) => { console.log(result); });
  // }

