import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  products : any;
  currentUser : any;
  wishlistItems = [];
  constructor(private router: Router,private service : CustomerService)  { 
      //this.wishlistItems= this.service.wishlistItems;
    
  }
  
  ngOnInit() {
    this.currentUser = JSON.parse(localStorage.getItem("user"));
    //console.log(this.currentUser.customerId)
    //this.service.getFavorites().subscribe( (result: any) => {console.log(result); this.products = result; });
    this.service.getFavorites().subscribe( (result: any) => {console.log(result); this.products = result; });
    console.log("......");
    console.log(this.products);
    console.log("......");
  }

  addToCart(product){
    //console.log("The cart items are : " + product);
    this.service.addToCart(product);
  }
}
