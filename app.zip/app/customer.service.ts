import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { EncrDecrServiceService } from './encr-decr-service.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class CustomerService {
  isUserLogged: any;
  private isAgent : any;
  cartItems = [];
  cartItemsAux = [];
  favourites = [];
  email : string;
  items = []; 
  item:any;
  productToBeAdded: Subject<any>;
  itemToBeAdded : Subject<any>;
  constructor(private httpClient: HttpClient, private EncrDecr: EncrDecrServiceService, private router: Router) {
    this.isUserLogged = false;
    this.isAgent = false;
    this.productToBeAdded = new Subject();
   }
   setUserAgent() : void{
     this.isAgent = true;
   }
   setUserCustomer(): void{
     this.isAgent = false;
   }

   setUserLoggedIn(): void { // login success
    this.isUserLogged = true;
   }
   getUserLogged(): any { // call this in AuthGuard
     return this.isUserLogged;
   }
  //  logoutUser() {
  //   this.isUserLogged = false;
  //   this.removeItemsFromCart();
  //   localStorage.removeItem('user')
  //   localStorage.removeItem("product");
  //   this.router.navigate(['/login'])
  // }

   sendProduct(product:any):void {
      this.item = product;
   }

   getProduct():any {
     return this.item;
   }

   getDistrictList(): any{
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }
   getStateList() : any{
    return this.httpClient.get('https://restcountries.eu/rest/v2/all');
   }

  registerCustomer(customer: any) {
     var encrypted = this.EncrDecr.set('123456$#@$^@1ERF', customer.password);
     console.log(encrypted)
     customer.password = encrypted.split('/').join('')
     console.log(customer);
    return this.httpClient.post('Artisanal/webapi/myresource/register/', customer);
  }
  getCustomerByUserPass(loginId : any, password: any) : any{
    var encrypted = this.EncrDecr.set('123456$#@$^@1ERF', password);
    return this.httpClient.get('Artisanal/webapi/myresource/getCustomerByUserPass/'+loginId+'/'+encrypted.split('/').join(''));
  }
  registerAgent(agent: any) {
    // var encrypted = this.EncrDecr.set('123456$#@$^@1ERF', customer.password);
    // console.log(encrypted)
    // customer.password = encrypted.split('/').join('')
    // console.log(customer);
   return this.httpClient.post('Artisanal/webapi/myresource/registerAgent/',agent);
 }
  getAgentByUserPass(loginId : any, password: any) : any{
    return this.httpClient.get('Artisanal/webapi/myresource/getAgentByUserPass/'+loginId+'/'+password);
  }
  postFile(ImageForm: any, fileToUpload: File) {
    // const endpoint='RESTAPI/webapi/myresource/';
    const formData: FormData = new FormData();
    formData.append('productName', ImageForm.proName);
    formData.append('price', ImageForm.price);
    formData.append('description', ImageForm.description);
    formData.append('Image', fileToUpload, fileToUpload.name);
    formData.append('Category', ImageForm.catName);
    formData.append('Quantity', ImageForm.quantity); 
    formData.append('agentId', ImageForm.agentId);


    return this.httpClient.post('Artisanal/webapi/myresource/registerProduct/', formData);
  }

  getProducts() {
    return this.httpClient.get('Artisanal/webapi/myresource/getProducts').pipe(retry(10));
  }


  addToCart(product: any) {
    this.productToBeAdded.next(product); //publishing
    this.cartItems.push(product);
    //localStorage.setItem('cartItems', JSON.stringify(this.cartItems));
  }
  getForCart() {
    return this.productToBeAdded.asObservable();
  }
  removeItemsFromCart(){
    this.cartItemsAux = this.cartItems;
    this.cartItems = [];
  }
  addProductToCart(prodcuts: any) {
    localStorage.setItem("product", JSON.stringify(prodcuts));
  }
  getProductFromCart() {
    //return localStorage.getItem("product");
    return JSON.parse(localStorage.getItem("product"));
  }
  removeAllProductFromCart() {
    return localStorage.removeItem("product");
  }



  
  getProductsByCategory(pots :string) {
    return this.httpClient.get('Artisanal/webapi/myresource/getProductsByCat/'+pots).pipe(retry(10));
  }
  confirmOrder(orderedDate, deliveryAddress, phoneNo, totalPrice) : any{
    let customer = JSON.parse(localStorage.getItem("user"));

    const formData: FormData = new FormData();
    formData.append('deliveryAdress', deliveryAddress);
    formData.append('orderedDate', orderedDate);
    formData.append('phoneNo', phoneNo);
    formData.append('totalPrice', totalPrice);
    formData.append('customerId', customer.customerId);
    formData.append('email', customer.emailId);
    formData.append('items', JSON.stringify(this.cartItems));


    return this.httpClient.post('Artisanal/webapi/myresource/confirmOrder/', formData);
    
  }
  update(customer: any) {
    console.log("In service");
    return this.httpClient.put('Artisanal/webapi/myresource/updateCustomer', customer);
   }

   updateProduct(product : any){
    return this.httpClient.put('Artisanal/webapi/myresource/updateProduct', product);

   }
   addToWishlist(product: any) {
    
    let customer = JSON.parse(localStorage.getItem("user"));

 const formData: FormData = new FormData();
 formData.append('productId', product.proId);
 formData.append('productName', product.proName);
 formData.append('price', product.price);
 formData.append('description', product.description);
 formData.append('Image',  product.proImage);
 formData.append('Category', product.catName);
 formData.append('Quantity', product.quantity); 
 formData.append('customerId', customer.customerId);
 console.log("....." + product.proId);
 
 console.log("cid....." + customer.customerId);

 return this.httpClient.post('Artisanal/webapi/myresource/addtowishlist/', formData);

}
getFavorites() {
  return this.httpClient.get('Artisanal/webapi/myresource/getFavorites').pipe(retry(10));
}
getOrders(customerId : number){
  console.log("service called........");
  return this.httpClient.get('Artisanal/webapi/myresource/getOrders/' +customerId);
}
cancelOrder(id){
  return this.httpClient.delete('Artisanal/webapi/myresource/cancelOrder/'+ id);
}

}
 