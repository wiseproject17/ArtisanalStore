import { Component, OnInit } from '@angular/core';
import { CustomerService } from '../customer.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order-details',
  templateUrl: './order-details.component.html',
  styleUrls: ['./order-details.component.css']
})
export class OrderDetailsComponent implements OnInit {

  products : any;
  user:any;
  id = [];
  flag : number;
  constructor(private router: Router,private service: CustomerService) {
    this.flag = 1;
  }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
    console.log(this.user.customerId);
    this.service.getOrders(this.user.customerId).subscribe( (result: any) => {console.log(result); this.products = result; });
    //console.log(this.product);
  }
  cancelOrder(items){
    console.log(items[0].orderDetailId);
    var inputValue = document.getElementById("cancelbtn")["value"];
    this.service.cancelOrder(items[0].orderDetailId).subscribe((result : any) => {
      document.getElementById("cancelbtn").innerText = "cancelled";
      this.flag = 0;
    });
  }

}
