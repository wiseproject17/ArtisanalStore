import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { ViewChild,ElementRef } from '@angular/core'
import { ToastrService } from 'ngx-toastr';
import { EncrDecrServiceService } from '../encr-decr-service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
  @ViewChild('loginRef', {static: true })
  loginElement: ElementRef;
  customer : any;
  user: any;
  agent: any;
  auth2: any;
  //password:string;
  constructor(private router: Router, private EncrDecr: EncrDecrServiceService,private toastr: ToastrService, private customerService: CustomerService) {
    //var encrypted = this.EncrDecr.set('123456$#@$^@1ERF', this.user.password);
    //encrypted = encrypted.split('/').join('');
    this.user = {loginId: '', password:''};
  }


  ngOnInit() {
    document.body.classList.add('loginbg-img');
    this.googleInitialize();
  }
  ngOnDestroy(){
    document.body.classList.remove('loginbg-img');
  }
  AgentloginSubmit(AgentloginForm: any): void {
    if(AgentloginForm.loginId == 'admin@gmail.com' && AgentloginForm.password == 'admin') {
      this.router.navigate(['agentRegister']);
    }
    else{
      this.customerService.getAgentByUserPass(AgentloginForm.loginId , AgentloginForm.password).subscribe((result: any) => {
        this.agent = result;
        if(this.agent == null){
          //alert('Invalid Credentials..');
          this.toastr.success('Enter valid credentials','Invalid credentials',{timeOut:2000});
        }
        else{
          this.customerService.setUserLoggedIn();
          this.customerService.setUserAgent();
          //alert('login successful');
          this.toastr.success('Successfull','Login',{timeOut:2000});
          localStorage.setItem('user', JSON.stringify(this.agent));
          this.router.navigate(['agentProduct']);
        }
      });
    }
    
}
  loginSubmit(loginForm: any): void {

    this.customerService.getCustomerByUserPass(loginForm.loginId , loginForm.password).subscribe((result: any) => {
      this.customer = result;
      if(this.customer == null){
        //alert('Invalid Credentials..');
        this.toastr.success('Enter valid credentials','Invalid credentials',{timeOut:2000});
      }
      else{
        this.customerService.setUserLoggedIn();
        this.customerService.setUserCustomer();
        //alert('login successful');
        this.toastr.success('Successfull','Login',{timeOut:2000});
        localStorage.setItem('user', JSON.stringify(this.customer));
        this.router.navigate(['product']);

      }
    });
  }
  googleInitialize() {
    window['googleSDKLoaded'] = () => {
      window['gapi'].load('auth2', () => {
        this.auth2 = window['gapi'].auth2.init({
          client_id: '959702635984-ddrmm93dtuq6vssau059bk45sdbg9olm.apps.googleusercontent.com',
          cookie_policy: 'single_host_origin',
          scope: 'profile email'
        });
        this.prepareLogin();
      });
    }
    (function(d, s, id){
      var js, fjs = d.getElementsByTagName(s)[0];
      if (d.getElementById(id)) {return;}
      js = d.createElement(s); js.id = id;
      js.src = "https://apis.google.com/js/platform.js?onload=googleSDKLoaded";
      fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'google-jssdk'));
  }

  prepareLogin() {
    this.auth2.attachClickHandler(this.loginElement.nativeElement, {},
      (googleUser) => {
        let profile = googleUser.getBasicProfile();
        console.log('Token || ' + googleUser.getAuthResponse().id_token);
        console.log('Image URL: ' + profile.getImageUrl());
        console.log('Email: ' + profile.getEmail());

        alert('login successful');
        this.router.navigate(['product']);

      }, (error) => {
        alert(JSON.stringify(error, undefined, 2));
      });
  }
}
