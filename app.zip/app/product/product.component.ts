import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {
  products: any;
  user: any; 
  pots:string;
  constructor(private router: Router,private service: CustomerService) {

  }
  ngOnInit() {
  
    this.service.getProducts().subscribe( (result: any) => {console.log(result); this.products = result; });
  }
  allProducts(){
    this.service.getProducts().subscribe( (result: any) => {console.log(result); this.products = result; });
  }
  getproductsByCat(pots) {
    console.log(pots);
    this.service.getProductsByCategory(pots).subscribe( (result: any) => {console.log(result); this.products = result; });
  }
  
  addToCart(product){
    //console.log("The cart items are : " + product);
    this.service.addToCart(product);
  }
  addToWishlist(product){
    //console.log("wishList" + product);
    this.service.addToWishlist(product).subscribe();
  }

}