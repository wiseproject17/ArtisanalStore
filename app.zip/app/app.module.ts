import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { MatIconModule } from '@angular/material/icon';


import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { MobilePipe } from './mobile.pipe';
import { RegisterComponent } from './register/register.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { OrderDetailsComponent } from './order-details/order-details.component';
import { CartComponent } from './cart/cart.component';

import { AuthGuard } from './auth.guard';
import { HomeComponent } from './home/home.component';
import { ProductComponent } from './product/product.component';
import { AgentProductComponent } from './agent-product/agent-product.component';
import { AddProductComponent } from './add-product/add-product.component';
import { LogoutComponent } from './logout/logout.component';
import { EncrDecrServiceService } from './encr-decr-service.service';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ToastrModule } from 'ngx-toastr';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { UpdateComponent } from './update/update.component';
import { from } from 'rxjs';
import { WishlistComponent } from './wishlist/wishlist.component';
import {MAT_FORM_FIELD_DEFAULT_OPTIONS} from '@angular/material/form-field';
import { AgentRegisterComponent } from './agent-register/agent-register.component';


const appRoot: Routes = [{path: '', component: HomeComponent},
                         {path: 'login', component: LoginComponent},
                         {path: 'home', component: HomeComponent},
                         {path: 'product', component: ProductComponent},
                         {path: 'addProduct', component: AddProductComponent},
                         {path: 'logout', component: LogoutComponent},
                         {path: 'agentProduct', component: AgentProductComponent},
                         {path: 'register', component: RegisterComponent},
                         {path: 'cart',component:CartComponent},
                         {path: 'order-details',component:OrderDetailsComponent},
                         {path: 'update',component:UpdateComponent},
                         {path: 'agentRegister',component:AgentRegisterComponent},
                         {path: 'wishlist',component:WishlistComponent}
                        //  {path: 'addProduct/login', component: LoginComponent},
                        //  {path: 'product/home', component: HomeComponent},
                        //  {path: 'agentProduct/home', component: HomeComponent},
                        //  {path: 'agentProduct/addProduct', component: AddProductComponent},
                        //  {path: 'agentProduct/addProduct/agentProduct', component: AgentProductComponent},
                        // {path: 'agentProduct/home',component: HomeComponent},
                        // {path: 'agentProduct/addProduct/home', component: HomeComponent},
                        // {path: 'order-details',component:OrderDetailsComponent},
                        // {path: 'product/cart',component:CartComponent}

];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    MobilePipe,
    RegisterComponent,
    HeaderComponent,
    FooterComponent,
    HomeComponent,
    ProductComponent,
    AgentProductComponent,
    AddProductComponent,
    LogoutComponent,
    OrderDetailsComponent,
    CartComponent,
    UpdateComponent,
    WishlistComponent,
    AgentRegisterComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(), 
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule, 
    RouterModule.forRoot(appRoot),
    NgbModule,
    MatIconModule
  ],
  providers: [AuthGuard,EncrDecrServiceService,{ provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'fill' } }],
  bootstrap: [AppComponent]
})
export class AppModule { }
