import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerService } from '../customer.service';
import { EncrDecrServiceService } from '../encr-decr-service.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit, OnDestroy {
  district: any;
  state: any;
  customer: any;
  constructor(private router: Router,private service: CustomerService,private toastr: ToastrService,private EncrDecr: EncrDecrServiceService) {
    this.customer = {customerId: '',address: '', district: '',emailId: '', password: '', phone: '',state:'', userName: '',conPassword: ''

    };
  }

  ngOnInit() {
    document.body.classList.add('registerbg-img');
    this.service.getDistrictList().subscribe((data: any) => {console.log(data); this.district = data; });
    this.service.getStateList().subscribe((data: any) => {console.log(data); this.state = data; });
  }
  ngOnDestroy(){
    document.body.classList.remove('registerbg-img');
  }
  register(): void {
    this.service.registerCustomer(this.customer).subscribe((result: any) => { console.log(result); } );
    console.log(this.customer);
    //alert('Registration Successful');
    this.toastr.success('For Registering','Thank You',{timeOut:2000});
    this.router.navigate(['login']);
  }
}
